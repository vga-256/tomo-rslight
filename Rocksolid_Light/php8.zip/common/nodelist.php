<?php
include "head.inc";

echo '<h4><p align="left">Welcome to Rocksolid</p>';
echo '<p align="left">How to access and what’s available</p></h4><br />';

echo '<font size="4em">';
echo '<b>Rocksolid Light:</b><br /><a href="http://rslight.i2p">rslight.i2p</a><br /><a href="http://fev4bgoasgxttqb3x3tukxxia6lwryteq6a2ramqb2gjiol3zbu6xaid.onion">fev4bgoasgxttqb3x3tukxxia6lwryteq6a2ramqb2gjiol3zbu6xaid.onion</a><br /><a href="https://news.novabbs.org">news.novabbs.org</a><br />';
echo '<br />';
echo '<b>retroBBS:</b><br /><a href="http://retrobbs.i2p">retrobbs.i2p</a><br /><a href="http://retrobbs2.i2p">retrobbs2.i2p</a><br /><a href="https://www.rocksolidbbs.com">www.rocksolidbbs.com</a><br />';
echo '<br />';
echo '<b>novaBBS:</b><br /><a href="https://www.novabbs.com">www.novabbs.com</a><br />';
echo '<br />';

echo 'Newsreader Access:<br />';
echo 'v77lu6t26velvaddm4gibyzd5sogskuczp7vwoc4vxmukvvaucva.b32.i2p<br />';
echo 'zkcvkb5xprurx5dvpanhyivneuzah6k6xayxgxd4h2ekklxgoi2x5aad.onion:119<br />';
echo 'news.novabbs.org:119 or 563<br />';
echo '<br />';
echo 'Create NNTP Account: Use one of the <i>Rocksolid Light</i> links above to create account.<br />';
echo 'NNTP Peering also available in i2p/tor/clearnet<br />';
echo '<br />';
echo 'Rocksolid is also available from any usenet news provider carrying the rocksolid.* hierarchy<br />';
echo '<br />';

echo 'Questions? Post in rocksolid.shared.rocksolid (Rocksolid)';
echo '</font><br /><br />';
?> 
