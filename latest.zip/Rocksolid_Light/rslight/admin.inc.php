<?php
  $admin = array();
  $admin['password'] = '<admin_password>';
  $admin['key'] = '<admin_key>';
?>
