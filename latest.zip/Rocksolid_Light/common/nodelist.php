<?php
include "head.inc";
?>
<h4>
<p align="left">Welcome
to Rocksolid</p>
<p align="left">How
to access and what’s available:</p>
</h4>
<br />
<font size='2em'>
<p align="left">i2p
Web forums: <a href="http://def2.i2p/">def2.i2p</a>
   <a href="http://def3.i2p/">def3.i2p</a>    <a href="http://def4.i2p/">def4.i2p</a>
       <a href="http://retrobbs.i2p/">retrobbs.i2p</a>
   <a href="http://novabbs.i2p/">novabbs.i2p</a>    <a href="http://rslight.i2p/">rslight.i2p</a></p>
<p align="left">Tor
Web Forums: <a href="http://z5bqfv5v75kxy7pj.onion/">z5bqfv5v75kxy7pj.onion</a>
   <a href="http://dkzerogt6z6ybhcj.onion/">dkzerogt6z6ybhcj.onion</a>
   <a href="http://j7zbybfl5ho2rta3.onion/">j7zbybfl5ho2rta3.onion</a></p>
<p align="left">Clearnet
Web Forums:
<a href="http://www.rocksolidbbs.com/">www.rocksolidbbs.com</a>   
<a href="http://www.novabbs.com/">www.novabbs.com</a>
<a href="http://news.novabbs.org/">news.novabbs.org</a></p>
<br />
<p align="left">NNTP
Newsreader Access: 
</p>
<p align="left">dgqrm3ouc5cqct7yzlk35qpq2hlkm3v3gegzvkyahvo67ulronhq.b32.i2p</p>
<p align="left">asq5mo52aghemn2i.onion:119</p>
<p align="left">news.i2pn2.org:119, 563</p>
<br />
<p align="left">Create
NNTP Account: <a href="http://rslight.i2p/">rslight.i2p</a>
   <a href="http://dkzerogt6z6ybhcj.onion/">dkzerogt6z6ybhcj.onion</a>
   <a href="http://news.novabbs.org/">news.novabbs.org</a>
<p align="left"NNTP
Peering and FTN Connections also available in i2p/tor/ clearnet</p>
</p>
<br />
<p align="left" style="margin-bottom: 0.06in">Questions?
Post in rocksolid.shared.rocksolid (Rocksolid)</p>
<p align="left" style="margin-bottom: 0.06in"><br/>
<br/>

</p>
</font>
</body>
</html>
